/**
 * Jetpack Gallery Settings
 */
(function($) {
	var media = wp.media;

	// Wrap the render() function to append controls.
	media.view.Settings.Gallery = media.view.Settings.Gallery.extend({
		render: function() {
			var $el = this.$el;

			media.view.Settings.prototype.render.apply( this, arguments );

			// Append the type template and update the settings.
			$el.append( media.template( 'jetpack-gallery-settings' ) );
			media.gallery.defaults.type = 'default'; // lil hack that lets media know there's a type attribute.
			this.update.apply( this, ['type'] );

			$el.append( media.template( 'drgal-easing-settings' ) );
			media.gallery.defaults.easing = 'default'; // lil hack that lets media know there's a type attribute.
			this.update.apply( this, ['easing'] );

			$el.append( media.template( 'drgal-direction-settings' ) );
			media.gallery.defaults.direction = 'default'; // lil hack that lets media know there's a type attribute.
			this.update.apply( this, ['direction'] );

			$el.append( media.template( 'drgal-speed-settings' ) );
			media.gallery.defaults.speed = '1500,3500'; // lil hack that lets media know there's a type attribute.
			this.update.apply( this, ['speed'] );

			// Hide the Columns setting for all types except Default
			$el.find( 'select[name=type]' ).on( 'change', function () {
				var columnSetting = $el.find( 'select[name=columns]' ).closest( 'label.setting' );

				if ( 'default' == $( this ).val() ){
					columnSetting.show();
				}else{
					columnSetting.hide();
				}
				// dani: hide cube-object, if not used
				if( 'imagecube' == $( this ).val()  ){
				  $el.find( 'select[name=easing]' ).closest( 'label.setting' ).show();
				  $el.find( 'select[name=direction]' ).closest( 'label.setting' ).show();
				  $el.find( 'input[name=speed]' ).closest( 'label.setting' ).show();
				}else{
				  $el.find( 'select[name=easing]' ).closest( 'label.setting' ).hide();
				  $el.find( 'select[name=direction]' ).closest( 'label.setting' ).hide();
				  $el.find( 'input[name=speed]' ).closest( 'label.setting' ).hide();
				}
			  
			} ).change();


			return this;
		}
	});
	
})(jQuery);



